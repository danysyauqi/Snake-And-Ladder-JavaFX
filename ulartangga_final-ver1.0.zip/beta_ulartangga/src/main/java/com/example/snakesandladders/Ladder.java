package com.example.snakesandladders;

public class Ladder extends PowerElement {

    public Ladder(int[][] ladderPositions) {
        super(ladderPositions, "src/main/resources/audio/powerUp.wav");
    }
    
}