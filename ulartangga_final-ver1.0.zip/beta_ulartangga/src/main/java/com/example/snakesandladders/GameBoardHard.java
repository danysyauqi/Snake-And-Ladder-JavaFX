package com.example.snakesandladders;

import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

public class GameBoardHard extends GameHardController {

    private final PowerElement [] powerElements;
    private final Player[] players;
    private final Dice dice;

    public GameBoardHard(ImageView player1moverHard, ImageView player1tokenHard, ImageView player2moverHard,
            ImageView player2tokenHard, Button diceButton, ImageView diceHolder) {
                int[][] laddersEasy = {{5,25},{19,40},{27,47},{52,71},{55,86},{63,83},{79,81}};
                Ladder ladders1 = new Ladder(laddersEasy);
                int[][] snakes = {{99,64},{97,46},{92,87},{91,54},{61,43},{61,43},{56,6},{60,23},{37,2},{28,9}};
                Snake snakes1 = new Snake(snakes);
                this.powerElements = new PowerElement[2];
                this.powerElements[0] = snakes1;
                this.powerElements[1] = ladders1;
                this.players = new Player[2];
                this.players[0] = new Player(player1moverHard, player1tokenHard);
                this.players[1] = new Player(player2moverHard, player2tokenHard);
                this.dice = new Dice(diceButton, diceHolder);
    }

    private <T extends PowerElement> boolean checkForSnakesAndLadders(int player, int currentPlayerPosition, T element){
        int destinationTile = currentPlayerPosition;
        int[] destination = CoordinateLookup.getCoordinates(currentPlayerPosition);
        if (element.isPowerElement(currentPlayerPosition)){
            destination = element.destinationCoordinates(currentPlayerPosition);
            destinationTile = element.destinationTileNumber(currentPlayerPosition);
            this.players[player-1].moveToTile(destinationTile, destination);
            return true;
        }
        return false;
    }

    private int checkForSpecialTiles(int player) {
        int currentPlayerPosition = this.players[player-1].getCurrentPosition();
        if (currentPlayerPosition == 100)
            return 1;
        for (PowerElement element: this.powerElements) {
            if(checkForSnakesAndLadders(player, currentPlayerPosition, element))
                break;
        }
        return 0;
    }

    public int playhard(MouseEvent event, int player) {
        if (!(this.players[player-1].isLocked()))
            this.players[player-1].repeat(event);
        return checkForSpecialTiles(player);
    }

    public void moveTokenByOne(MouseEvent event, int player) {
        this.players[player-1].moveByOne();
    }

    public void rollDice(int player) {
        int dieRoll = dice.roll();
        if (this.players[player-1].getCurrentPosition() + dieRoll > 100)
            return;
        this.players[player-1].setCurrentDieRoll(dieRoll);
        if (dieRoll == 6)
            this.players[player-1].setLocked(false);
    }
    
}
