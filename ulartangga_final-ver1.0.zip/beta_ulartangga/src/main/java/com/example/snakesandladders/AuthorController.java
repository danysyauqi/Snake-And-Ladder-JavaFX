package com.example.snakesandladders;
import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;


public class AuthorController {
    private Stage stage;
    private Scene scene;

    @FXML
    private Button exButton;

    @FXML
    private ImageView backgroundcredit;

    public void manualGuide (ActionEvent event) throws IOException{
        Object root = FXMLLoader.load(getClass().getResource("manualguide.fxml"));
        stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        scene = new Scene((Parent) root);
        stage.setScene(scene);
        stage.show();
    }

    public void moveToScreen1(ActionEvent event) throws IOException{
        
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Back To Home");
        alert.setHeaderText("Are you sure you want to back home?");
        alert.setContentText("Click OK to back home, or Cancel to stay.");
        if(alert.showAndWait().get() == ButtonType.OK){
            
            Parent root = FXMLLoader.load(getClass().getResource("scene1.fxml"));
            stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
    
        }
    }
}
